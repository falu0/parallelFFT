In this folder you will find:

- fft.cpp : the c++ code implementing the parallel FFT algorithm.
- performance_measure folder : it contains the results of the experiments run, properly formatted for the gnuplot plotting tool.
		In addition to the performance of the proposed solution, it includes also the results obtained by some variation of the fft
		algorithm; I find it useful to make some comparison. 
- plots folder: it contains the plots for the performance_measures folder.
- gnuplot_command: the gnuplot command used to produce the plots.
- report : the project report, detailing the problem and its solution.
- libiomp5.so : the proper omp library needed by the Xeon Phi coprocessor to run the application