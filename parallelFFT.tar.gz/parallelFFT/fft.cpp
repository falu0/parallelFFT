/***
Fabio Luchetti - 492470

Distributed System: Paradigms and Models project

The Fast Fourier Transform - Parallel implementation
***/


#include <ff/pipeline.hpp>
#include <ff/farm.hpp>
#include <ff/parallel_for.hpp>
#include <omp.h>
#include <thread>

#include <iostream>
#include <sstream>      // std::stringstream
#include <fstream>

#include <algorithm>    // std::min_element, std::max_element

#include <math.h>
#include <numeric>

#include <time.h>
timespec begin, end;
timespec startt_main, endt_main, startt_twiddler, endt_twiddler, startt_fft, endt_fft;


using namespace ff;


#define PI 3.141592653589793238462643383279502884197169399375105820974944
#define BILLION 1E9
#define C_MUL(res,a,b) \
{ (res).r = (a).r*(b).r - (a).i*(b).i; (res).i = (a).r*(b).i + (a).i*(b).r; }
#define C_MULBYSCALAR(c,s) \
{ (c).r *= (s); (c).i *= (s); }
#define C_DIVBYSCALAR(c,s) \
{ (c).r /= (s); (c).i /= (s); }
#define  C_ADD(res,a,b) \
{ (res).r=(a).r+(b).r;  (res).i=(a).i+(b).i; }
#define  C_SUB(res,a,b) { (res).r=(a).r-(b).r;  (res).i=(a).i-(b).i; }



//A complex number data type
struct complex_t {
    complex_t() {}
    complex_t(double r, double i) : r(r),i(i) {}
    double r;
    double i;
};


/** utilities **/

double mean(std::vector<double> &v) {
    double v_sum = std::accumulate(v.begin(), v.end(), 0.0);
    double v_mean = v_sum / v.size();
}

double median(std::vector<double> &v) {
    size_t n = v.size() / 2;
    nth_element(v.begin(), v.begin()+n, v.end());
    return v[n];
}

//courtesy of http://graphics.stanford.edu/~seander/bithacks.html#DetermineIfPowerOf2
bool is_powerOfTwo (unsigned int v) {
    return (v && !(v & (v - 1)));
}

void slow_fun() {
    // this function does nothing. volatile prevents
    // compiler optimizations to remove it from the executable
    volatile float x = 1.0;
    for (int i=0;i<1;i++) {
        x = sin(x);
    }
}

void fillv (complex_t v[], const int size) {

    for (int i=0;i<size;i++)  {
        //v[i].r= (((double) rand() / (double) RAND_MAX) * 200) - 100; //in (-100,100)
        //v[i].i= (((double) rand() / (double) RAND_MAX) * 200) - 100; //in (-100,100)
        //simpler for debugging
        v[i].r = (double) i;
        v[i].i = (double) 0;

    }
}

void prettyprintv ( complex_t v[], const int size, std::string const& s) {
    std::cout <<  s << std::endl;
    for ( int i = 0; i < size; i++ ) {
        std::cout <<  i << " " << v[i].r << " i" << v[i].i << std::endl; //different lines
        //std::cout <<  i << " " << v[i].r << " " << v[i].i << "\t"; //same line, tab spaced
    }
}

timespec timediff(timespec t1, timespec t2) {
    timespec res;
    if (!((t2.tv_nsec-t1.tv_nsec)<0)) {
        res.tv_sec = t2.tv_sec-t1.tv_sec;
        res.tv_nsec = t2.tv_nsec-t1.tv_nsec;
    } else {
        res.tv_sec = t2.tv_sec-t1.tv_sec-1;
        res.tv_nsec = BILLION+t2.tv_nsec-t1.tv_nsec;
    }
    return res;
}

timespec timesum(timespec t1, timespec t2) {
    timespec res;
    res.tv_sec = t1.tv_sec + t2.tv_sec ;
    res.tv_nsec = t1.tv_nsec + t2.tv_nsec ;
    if (res.tv_nsec >= BILLION) {		/* Carry? */
        res.tv_sec++;
        res.tv_nsec = res.tv_nsec - BILLION;
    }
    return res;
}

int  timecompare (timespec t1, timespec t2) {

    if (t1.tv_sec < t2.tv_sec)
    return (-1) ;				//Less than
    else if (t1.tv_sec > t2.tv_sec)
    return (1) ;				//Greater than
    else if (t1.tv_nsec < t2.tv_nsec)
    return (-1) ;				//Less than
    else if (t1.tv_nsec > t2.tv_nsec)
    return (1) ;				//Greater than
    else
    return (0) ;				//Equal

}

timespec timeavg (timespec times[], const int size) {

    timespec avg; avg.tv_sec=0; avg.tv_nsec=0;

    for (int i=0; i<size; i++) {
        avg.tv_nsec += ( (times[i].tv_sec*BILLION) + times[i].tv_nsec ) ;
    }
    avg.tv_nsec/=size;
    while (avg.tv_nsec >= BILLION) {
        avg.tv_sec++ ;  avg.tv_nsec-=BILLION;
    }
    return avg;

}

double timecv(timespec times[], const int size){

    double cv; //coefficient of variation

    //standard deviation, mean, variance, sum of deviations, all expressed in ns
    double stddev, mean=0, var, sumdevs = 0;

    double times_as_ns[size]; //times expressed as ns only

    for (int i=0; i<size; i++) {
        times_as_ns[i] = (times[i].tv_sec*BILLION) + times[i].tv_nsec;
        mean += times_as_ns[i];
    }
    mean/=size;

    for(int i=0; i<size; i++){
        sumdevs += (times_as_ns[i] - mean)*(times_as_ns[i] - mean);
    }

    var = sumdevs / (size - 1); //size-1 gives Bessel's correction
    stddev = sqrt(var);

    cv = (stddev / mean) * 100;

    // Standard Deviation in timespec
    // timespec sd; sd.tv_sec=0; sd.tv_nsec=0;
    // while (stddev >= BILLION) {
    //     sd.tv_sec++ ;  stddev-=BILLION;
    //
    // }
    // sd.tv_nsec=stddev;

    return cv;

}

double  time2Double (timespec t) {
    return ((double) t.tv_sec + (t.tv_nsec / BILLION)) ;
}

timespec  double2Time (double d) {
    timespec res;
    res.tv_sec = (long) d;
    res.tv_nsec = (d - ((long)d))*BILLION;
    return res;
}

/*********/


//Fast Singleton's method. Does not suit for parallelization
void twiddler (complex_t * w, int N, bool is_inverse) {

    int L;

    double theta = 2*PI/N;
    double S = (sin(theta));
    double C = (1-2*(pow(sin(theta/2),2))); //Call library function sin to compute S and C
    w[0].r = 1; w[0].i = 0; //   Initialize  ((w)^0)_N = cos(0) + j sin(0)
    for (int K=0; K<= N/8 - 2; K++) { //Compute the first N/8 factors
        w[K + 1].r = C * w[K].r - S * w[K].i;
        w[K + 1].i = S * w[K].r + C * w[K].i;
    }
    L = N/8; //Store the next N/8 factors
    w[L].r = sqrt(2)/2; w[L].i = sqrt(2)/2; //((w)^(N/8))_N = cos(PI/4) + j sin(PI/4)
    for (int K=1; K<= N/8 - 1; K++) {
        w[L + K].r = w[L - K].i;
        w[L + K].i = w[L - K].r;
    }
    L = N/4; //Store the next N/4 factors
    w[L].r = 0; w[L].i = 1; //((w)^(N/4))_N = cos(PI/2) + j sin(PI/2)
    for (int K = 1; K<= N/4 - 1; K++) {
        w[L + K].r = -w[L - K].r;
        w[L + K].i = w[L - K].i;
    }


// w is negated when used in inverse tranform
if (is_inverse) {
    for (int K = 0; K<N/2; K++) {
        w[K].i *= -1;
    }
}
return;
}

/*void twiddler_old (complex_t * w, int n) {
//The trivial algorithm. It suites for parallelization
for (int i=0 ; i<n ; i++) {
twiddles[i].r= cos(2*i*PI/n);
twiddles[i].i= sin(2*i*PI/n);
}
}*/


/* Perform the FFT algorithm with decimation in frequency decomposition.
* a is the input, b is the output, they are bot in natural order.
* w is the twiddle factor array, N is the size of the problem,
* is_inverse indicates if the procedure should perform the antitransformation
*/
//NOTE Slower than fft_dit.
void fft_dif (complex_t *& a, complex_t *& b, complex_t *& w, int N, bool is_inverse) {

    std::cout << "* Sequential FFT diF, N="<< N << " *" << std::endl;

    int NumOfProblems = 1;
    int ProblemSize = N;
    int Distance = 1;

    int J, K, JFirst, JLast, Jtwiddle;

    complex_t W,Temp;

    clock_gettime(CLOCK_MONOTONIC, &startt_fft);

    while (ProblemSize > 1) { //Halve each problem
        for(JFirst=0;JFirst<NumOfProblems;JFirst++) {
            J = JFirst;
            Jtwiddle = 0;
            K = JFirst;
            while (J < N-1) {
                W = w[Jtwiddle];
                C_ADD(b[J],a[K],a[K+N/2]); //b[J] = a[K] + a[K+N/2];
                C_SUB(Temp,a[K],a[K+N/2]);
                C_MUL(b[J+Distance],Temp,W); //b[J+Distance] = (a[K] - a[K+N/2]) * W
                Jtwiddle = Jtwiddle + NumOfProblems; //Assume w[l] = ((w)^l)_N
                J = J + 2*NumOfProblems;
                K = K + NumOfProblems;
            }
        }

        NumOfProblems = NumOfProblems * 2;
        ProblemSize = ProblemSize/2;
        Distance = Distance * 2;

        std::swap(a,b);

    }

    std::swap(a,b);

    clock_gettime(CLOCK_MONOTONIC, &endt_fft);


    //Normalize
    if (is_inverse) {
        for (int i = 0; i<N; i++) {
            C_DIVBYSCALAR(b[i],N);
        }

    }

    return;
}


/* Perform the FFT algorithm with decimation in time decomposition.
* a is the input, b is the output, they are bot in natural order.
* w is the twiddle factor array, N is the size of the problem,
* is_inverse indicates if the procedure should perform the antitransformation
*/
void fft_dit(complex_t *& a, complex_t *& b, complex_t *& w, int N, bool is_inverse) {

    std::cout << "* Sequential FFT diT, N="<< N << " *" << std::endl;

    int PairsInGroup = N/2; //Initially: N/2 pairs in one group
    int NumOfGroups = 1;
    int Distance = N/2; // redundant, same as PairsInGroup

    int L, JFirst, JLast, Jtwiddle;

    complex_t W, Temp;

    clock_gettime(CLOCK_MONOTONIC, &startt_fft);

    while (NumOfGroups < N) { //Combine pairs in each group
        L = 0;
        for (int K = 0; K < NumOfGroups; K++) {
            JFirst = 2 * K * PairsInGroup;
            JLast = JFirst + PairsInGroup;
            Jtwiddle = K * PairsInGroup; //Assume w[l] = ((w)^l)_N
            W = w[Jtwiddle]; //Same twiddle factor in each group
            for (int J = JFirst; J < JLast; J++) {
                C_MUL(Temp,W,a[J + Distance]) //Temp = W * a[J + Distance];
                C_ADD(b[L],a[J],Temp); //b[L] = a[J] + Temp;
                C_SUB(b[L+N/2],a[J],Temp); //b[L + N/2] = a[J] - Temp;
                L = L + 1;
            }
        }

        PairsInGroup = PairsInGroup/2;
        NumOfGroups = NumOfGroups*2;
        Distance = Distance/2;

        std::swap(a,b);
    }

    std::swap(a,b);


    clock_gettime(CLOCK_MONOTONIC, &endt_fft);


    //Normalize
    if (is_inverse) {
        for (int i = 0; i<N; i++) {
            C_DIVBYSCALAR(b[i],N);
        }

    }

    return;
}

//Parallelize the outer loop with omp parfor
void fft_dit_olomp (int nw, complex_t *& a, complex_t *& b, complex_t *& w, int N, bool is_inverse) {

    std::cout << "* Parallel FFT diT olomp, N="<< N << " nw=" << nw << " *" << std::endl;

    omp_set_num_threads(nw); // Use max nw threads for all consecutive parallel regions


    int PairsInGroup = N/2; //Initially: N/2 pairs in one group
    int NumOfGroups = 1;
    int Distance = N/2;

    int L, JFirst, JLast, Jtwiddle;

    complex_t W, Temp;

    clock_gettime(CLOCK_MONOTONIC, &startt_fft);

    while (NumOfGroups < N) { //Combine pairs in each group
        L = 0;
        #pragma omp parallel for private(L, Temp, JFirst, JLast, Jtwiddle, W)
        for (int K = 0; K < NumOfGroups; K++) {
            JFirst = 2 * K * PairsInGroup;
            JLast = JFirst + PairsInGroup - 1;
            Jtwiddle = K * PairsInGroup; //Assume w[l] = ((w)^l)_N
            W = w[Jtwiddle]; //Same twiddle factor in each group
            L = K * (JLast - JFirst + 1); //NOTE this line is added in omp version only
            for (int J = JFirst; J<=JLast; J++) {
                C_MUL(Temp,W,a[J + Distance]) //Temp = W * a[J + Distance];
                C_ADD(b[L],a[J],Temp); //b[L] = a[J] + Temp;
                C_SUB(b[L+N/2],a[J],Temp); //b[L + N/2] = a[J] - Temp;
                L = L + 1;
            }
        }

        PairsInGroup = PairsInGroup/2;
        NumOfGroups = NumOfGroups*2;
        Distance = Distance/2;

        std::swap(a,b);

    }

    std::swap(a,b);

    clock_gettime(CLOCK_MONOTONIC, &endt_fft);


    if (is_inverse) {
        //can trivially be parallelized with a parfor
        for (int i = 0; i<N; i++) {
            C_DIVBYSCALAR(b[i],N);
        }

    }

    return;
}

//Parallelize the outer loop with FastFlow parfor
void fft_dit_olffpf (int nw, complex_t *& a, complex_t *& b, complex_t *& w, int N, bool is_inverse) {

    std::cout << "* Parallel FFT diT olffpf, N="<< N << " nw=" << nw << " *" << std::endl;

    ParallelFor pf(nw);

    int PairsInGroup = N/2; //Initially: N/2 pairs in one group
    int NumOfGroups = 1;
    int Distance = N/2;

    int L, JFirst, JLast, Jtwiddle;

    complex_t W, Temp;

    int logN = (int)(log2(N));
    int t=0;
    timespec times[logN];

    clock_gettime(CLOCK_MONOTONIC, &startt_fft);

    while (NumOfGroups < N) { //Combine pairs in each group
        //for (int K = 0; K<NumOfGroups; K++)
        clock_gettime(CLOCK_MONOTONIC, &begin);

        pf.parallel_for_idx(0,NumOfGroups,1,0,[&](const long start, const long stop, const long idx) {
            if (start == stop) { return;}

            int L, JFirst, JLast, Jtwiddle;
            complex_t W, Temp;

            for (int K = start; K < stop; K++) {
                JFirst = 2 * K * PairsInGroup;
                JLast = JFirst + PairsInGroup;
                Jtwiddle = K * PairsInGroup; //Assume w[l] = ((w)^l)_N
                W = w[Jtwiddle]; //Same twiddle factor in each group
                L = K * (JLast - JFirst);
                for (int J = JFirst; J<JLast; J++) {
                    C_MUL(Temp,W,a[J + Distance]); //Temp = W * a[J + Distance];
                    C_ADD(b[L],a[J],Temp); //b[L] = a[J] + Temp;
                    C_SUB(b[L+N/2],a[J],Temp); //b[L + N/2] = a[J] - Temp;
                    L = L + 1;
                }
            }
        });
        //pf.ffStats(std::cout<<std::endl);

        clock_gettime(CLOCK_MONOTONIC, &end);
        times[t++] = timediff(begin, end);


        PairsInGroup = PairsInGroup/2;
        NumOfGroups = NumOfGroups*2;
        Distance = Distance/2;

        std::swap(a,b);

    }


    std::swap(a,b);

    clock_gettime(CLOCK_MONOTONIC, &endt_fft);

    // for(int i=0; i<logN; i++) {
    //     std::cout<< "\t times[" << i << "] = \t" <<times[i].tv_sec<<" : "<< std::setw(9)<<times[i].tv_nsec<<std::endl;
    // }


    if (is_inverse) {
        //can trivially be parallelized with a parfor
        for (int i = 0; i<N; i++) {
            C_DIVBYSCALAR(b[i],N);
        }
    }

    return;
}

//Parallelize the inner or outer loop with FastFlow parfor, according to their size
void fft_dit_ffpf (int nw, complex_t *& a, complex_t *& b, complex_t *& w, int N, bool is_inverse) {

    std::cout << "* Parallel FFT diT ffpf, N="<< N << " nw=" << nw << " *" << std::endl;

    ParallelFor pf(nw);

    int PairsInGroup = N/2; //Initially: N/2 pairs in one group
    int NumOfGroups = 1;
    int Distance = N/2;

    int /*L,*/ JFirst, JLast, Jtwiddle;

    complex_t W/*, Temp*/;

    // int logN = (int)(log2(N));
    // int t=0;
    // timespec stage_times[logN];


    clock_gettime(CLOCK_MONOTONIC, &startt_fft);

    while (NumOfGroups < N) { //Combine pairs in each group
        //clock_gettime(CLOCK_MONOTONIC, &begin);
        // (NumOfGroups < (nw)) is ok, but "math-check" and optimize if it is the case
        if (NumOfGroups < (nw) ) {

            for (int K=0; K<NumOfGroups; K++) {
                JFirst = 2 * K * PairsInGroup;
                JLast = JFirst + PairsInGroup;
                Jtwiddle = K * PairsInGroup; //Assume w[l] = ((w)^l)_N
                W = w[Jtwiddle]; //Same twiddle factor in each group

                pf.parallel_for_idx(JFirst,JLast,1,0,[&](const long start, const long stop, const long idx) {
                    if (start == stop) { return;}
                    complex_t Temp;
                    int L = (K * (JLast - JFirst)) + ((idx * (JLast - JFirst))/nw) ;// is this to be divisible for nw? YES
                    for(int J=start;J<stop;J++) {
                        C_MUL(Temp,W,a[J + Distance]); //Temp = W * a[J + Distance];
                        C_ADD(b[L],a[J],Temp); //b[L] = a[J] + Temp;
                        C_SUB(b[L+N/2],a[J],Temp); //b[L + N/2] = a[J] - Temp;
                        L = L + 1;
                    }

                });
            }
        } else {
            pf.parallel_for_idx(0,NumOfGroups,1,0,[&](const long start, const long stop, const long idx) {
                if (start == stop) { return;}
                int L, JFirst, JLast, Jtwiddle;
                complex_t W, Temp;

                for (int K = start; K < stop; K++) {
                    JFirst = 2 * K * PairsInGroup;
                    JLast = JFirst + PairsInGroup;
                    Jtwiddle = K * PairsInGroup; //Assume w[l] = ((w)^l)_N
                    W = w[Jtwiddle]; //Same twiddle factor in each group
                    L = K * (JLast - JFirst);
                    for (int J = JFirst; J < JLast; J++) {
                        C_MUL(Temp,W,a[J + Distance]); //Temp = W * a[J + Distance];
                        C_ADD(b[L],a[J],Temp); //b[L] = a[J] + Temp;
                        C_SUB(b[L+N/2],a[J],Temp); //b[L + N/2] = a[J] - Temp;
                        L = L + 1;

                    }
                }
            });
        }
        // clock_gettime(CLOCK_MONOTONIC, &end);
        // stage_times[t++] = timediff(begin, end);

        PairsInGroup = PairsInGroup/2;
        NumOfGroups = NumOfGroups*2;
        Distance = Distance/2;

        std::swap(a,b);

    }

    std::swap(a,b);

    clock_gettime(CLOCK_MONOTONIC, &endt_fft);

    // std::cout << "/* Stages mean time: " << time2Double(timeavg(times,logN)) << " cv: " << timecv(times,logN)<< std::endl;
    // std::cout << " cv: " << timecv(times,logN)<< std::endl;


    if (is_inverse) {
        for (int i = 0; i<N; i++) {
            C_DIVBYSCALAR(b[i],N);
        }
        //In parallel it would be:
        // pf.parallel_for_idx(0,N,1,0,[&](const long start, const long stop, const long idx) {
        //     if (start == stop) { return;}
        //     for (int i = start; i < stop; i++) {
        //         C_DIVBYSCALAR(b[i],N);
        //     }
        // );
    }

    return;
}

//*Simulate* the parallel dit fft, but instead of executing the butterfly
//operations it calls a dummy function that makes no memory accesses
void fft_dit_ffpf_slowfun (int nw, complex_t *& a, complex_t *& b, complex_t *& w, int N, bool is_inverse) {

    std::cout << "* Parallel FFT diT with slowfun, N="<< N << " nw=" << nw << " *" << std::endl;

    ParallelFor pf(nw);

    int PairsInGroup = N/2; //Initially: N/2 pairs in one group
    int NumOfGroups = 1;
    int Distance = N/2;

    int L, JFirst, JLast, Jtwiddle;

    complex_t W, Temp;


    clock_gettime(CLOCK_MONOTONIC, &startt_fft);

    while (NumOfGroups < N) { //Combine pairs in each group
        clock_gettime(CLOCK_MONOTONIC, &begin);
        //(NumOfGroups < (nw)) is ok, but "math-proof" it and optimize if it's the case
        if (NumOfGroups < (nw) ) {

            for (int K=0; K<NumOfGroups; K++) {
                JFirst = 2 * K * PairsInGroup;
                JLast = JFirst + PairsInGroup;
                Jtwiddle = K * PairsInGroup; //Assume w[l] = ((w)^l)_N
                W = w[Jtwiddle]; //Same twiddle factor in each group

                pf.parallel_for_idx(JFirst,JLast,1,0,[&](const long start, const long stop, const long idx) {
                    if (start == stop) { return;}
                    complex_t Temp;
                    int L = (K * (JLast - JFirst)) + ((idx * (JLast - JFirst))/nw) ;// is this to be divisible for nw? YES
                    //volatile int x;
                    for(int J=start;J<stop;J++) {
                        slow_fun();
                    }

                });

            }
        } else {
            pf.parallel_for_idx(0,NumOfGroups,1,0,[&](const long start, const long stop, const long idx) {
                if (start == stop) { return;}
                int L, JFirst, JLast, Jtwiddle;
                complex_t W, Temp;

                //volatile int x;
                for (int K = start; K < stop; K++) {
                    JFirst = 2 * K * PairsInGroup;
                    JLast = JFirst + PairsInGroup;
                    Jtwiddle = K * PairsInGroup; //Assume w[l] = ((w)^l)_N
                    W = w[Jtwiddle]; //Same twiddle factor in each group
                    L = K * (JLast - JFirst);
                    for (int J = JFirst; J < JLast; J++) {
                        slow_fun();
                    }
                }
            });
        }


        PairsInGroup = PairsInGroup/2;
        NumOfGroups = NumOfGroups*2;
        Distance = Distance/2;

        std::swap(a,b);

    }

    std::swap(a,b);

    clock_gettime(CLOCK_MONOTONIC, &endt_fft);


    if (is_inverse) {
        for (int i = 0; i<N; i++) {
            C_DIVBYSCALAR(b[i],N);
        }
    }

    return;
}

//*Simulate* the parallel dit fft, but instead of executing the proper butterfly
//operations, it operates with contiguous elements  in order to minimize cache misses
void fft_dit_ffpf_seracc (int nw, complex_t *& a, complex_t *& b, complex_t *& w, int N, bool is_inverse) {

    std::cout << "* Parallel FFT diT with seracc, N="<< N << " nw=" << nw << " *" << std::endl;

    ParallelFor pf(nw);

    int PairsInGroup = N/2; //Initially: N/2 pairs in one group
    int NumOfGroups = 1;
    int Distance = N/2;

    int L, JFirst, JLast, Jtwiddle;

    complex_t W, Temp;


    clock_gettime(CLOCK_MONOTONIC, &startt_fft);

    while (NumOfGroups < N) { //Combine pairs in each group
        clock_gettime(CLOCK_MONOTONIC, &begin);
        //NumOfGroups < (nw) is ok, but "math-check" and optimize if it is the case
        if (NumOfGroups < (nw) ) {

            for (int K=0; K<NumOfGroups; K++) {
                JFirst = 2 * K * PairsInGroup;
                JLast = JFirst + PairsInGroup;
                Jtwiddle = K * PairsInGroup; //Assume w[l] = ((w)^l)_N
                W = w[Jtwiddle]; //Same twiddle factor in each group

                pf.parallel_for_idx(JFirst,JLast,1,0,[&](const long start, const long stop, const long idx) {
                    if (start == stop) { return;}
                    complex_t Temp;
                    int L = (K * (JLast - JFirst)) + ((idx * (JLast - JFirst))/nw) ;// is this to be divisible for nw? YES
                    for(int J=start;J<stop;J++) {
                        C_ADD(b[J],a[J],a[J]); //b[J] = a[J] + Temp;
                        C_SUB(b[J],a[J],a[J]); //b[J] = a[J] + Temp;
                        C_ADD(b[J],a[J],a[J]); //b[J] = a[J] + Temp;
                        L = L + 1;
                    }

                });
            }
        } else {
            pf.parallel_for_idx(0,NumOfGroups,1,0,[&](const long start, const long stop, const long idx) {
                if (start == stop) { return;}
                int L, JFirst, JLast, Jtwiddle;
                complex_t W, Temp;

                for (int K = start; K < stop; K++) {
                    JFirst = 2 * K * PairsInGroup;
                    JLast = JFirst + PairsInGroup;
                    Jtwiddle = K * PairsInGroup; //Assume w[l] = ((w)^l)_N
                    W = w[Jtwiddle]; //Same twiddle factor in each group
                    L = K * (JLast - JFirst);
                    for (int J = JFirst; J < JLast; J++) {
                        C_ADD(b[J],a[J],a[J]); //b[L] = a[J] + Temp;
                        C_SUB(b[J],a[J],a[J]); //b[L] = a[J] + Temp;
                        C_ADD(b[J],a[J],a[J]); //b[L] = a[J] + Temp;
                        L = L + 1;
                    }
                }
            });
        }

        PairsInGroup = PairsInGroup/2;
        NumOfGroups = NumOfGroups*2;
        Distance = Distance/2;

        std::swap(a,b);

    }

    std::swap(a,b);

    clock_gettime(CLOCK_MONOTONIC, &endt_fft);


    if (is_inverse) {
        for (int i = 0; i<N; i++) {
            C_DIVBYSCALAR(b[i],N);
        }
    }

    return;
}


//sorry for that
void fft_massive_tests ( void (*f)(int, complex_t *&, complex_t *&, complex_t *&, int, bool), int num_of_trials, std::string filename) {

    const int nws_size = 10;
    const int nws[nws_size] = {1,2,4,8,15,16,32,64,128,232};

    const int npts_size = 6; // 2^ {12, 15, 18, 21, 24, 25}
    const int npts[npts_size] = {4096,32768,262144,2097152,16777216,33554432};


    std::vector<double> Tc_samples;
    double fftTc[nws_size][npts_size]; // averaged parallel fft completion times
    double fftTcSequential[npts_size]; // averaged sequential fft completion times

    const int hw_concurrency = sysconf( _SC_NPROCESSORS_ONLN );

    for (int i=0;i<npts_size;i++) { //for each npts
        complex_t * in = (complex_t*) malloc(sizeof (complex_t)*npts[i]);
        complex_t * out = (complex_t*) malloc(sizeof (complex_t)*npts[i]);
        fillv(in,npts[i]);
        complex_t * w = (complex_t*) malloc(sizeof (complex_t)*npts[i]/2);
        clock_gettime(CLOCK_MONOTONIC, &startt_twiddler);
        twiddler(w,npts[i], false);
        clock_gettime(CLOCK_MONOTONIC, &endt_twiddler);

        fft_dit(in,out,w,npts[i],false);
        fftTcSequential[i]=time2Double(timediff(startt_fft,endt_fft));
        //fftTcSequential[i] = -1.0;

        for (int j=0;j<nws_size;j++) { //for each nws
            if (nws[j]>hw_concurrency) { std::cout << "Skipping nws=" << nws[j]<< std::endl; continue; }
            Tc_samples.clear();
            for (int k=0;k<num_of_trials;k++) {
                (*f)(nws[j],in,out,w,npts[i],false);
                Tc_samples.push_back(time2Double(timediff(startt_fft,endt_fft)));
            }
            fftTc[j][i]=median(Tc_samples);
            std::cout << "The median completion time was " << fftTc[j][i] << " ms" << std::endl;

        }
        free(w);
        free (in);
        free (out);
    }

    /*********** Write performance measures to file. ***********/
    /*            The format is suited for gnuplot            */

    //could use an array, but hey... nevermind
    std::ofstream ofs_Tc, ofs_Scalability, ofs_Speedup, ofs_Efficiency;

    ofs_Tc.open(filename+"-Tc.txt",std::ofstream::out);
    ofs_Scalability.open(filename+"-Scalability.txt",std::ofstream::out);
    ofs_Speedup.open(filename+"-Speedup.txt",std::ofstream::out);
    ofs_Efficiency.open(filename+"-Efficiency.txt",std::ofstream::out);

    if ( !(ofs_Tc.is_open() && ofs_Scalability.is_open() && ofs_Speedup.is_open() && ofs_Efficiency.is_open()) ) {
        std::cerr << "Unable to open file" << filename << "\n";
        return;
    }

    //sort of header
    ofs_Tc << "#nw/npts";
    ofs_Scalability << "#nw/npts";
    ofs_Speedup << "#nw/npts";
    ofs_Efficiency << "#nw/npts";
    for (int i=0;i<npts_size;i++) {
        ofs_Tc << " " << npts[i];
        ofs_Scalability << " " << npts[i];
        ofs_Speedup << " " << npts[i];
        ofs_Efficiency << " " << npts[i];
    }
    ofs_Tc << std::endl;
    ofs_Scalability << std::endl;
    ofs_Speedup << std::endl;
    ofs_Efficiency << std::endl;


    for (int i=0;i<nws_size;i++) { //for each nws
        if (nws[i]>hw_concurrency) { continue; }
        ofs_Tc << nws[i] << "\t";
        ofs_Scalability << nws[i] << "\t";
        ofs_Speedup << nws[i] << "\t";
        ofs_Efficiency << nws[i] << "\t";
        for (int j=0;j<npts_size;j++) { //for each pts
            ofs_Tc << fftTc[i][j] << "\t";
            ofs_Scalability << fftTc[0][j]/fftTc[i][j] << "\t";
            ofs_Speedup << fftTcSequential[j]/fftTc[i][j] << "\t";
            ofs_Efficiency << (fftTcSequential[j]/fftTc[i][j])/nws[i] << "\t";
        }
        ofs_Tc << std::endl;
        ofs_Scalability << std::endl;
        ofs_Speedup << std::endl;
        ofs_Efficiency << std::endl;
    }

    ofs_Tc.close();
    ofs_Scalability.close();
    ofs_Speedup.close();
    ofs_Efficiency.close();

}


struct myTask {
    myTask(complex_t * a, complex_t * b, complex_t * w, const int N, const bool is_inverse):
    a(a),b(b),w(w),N(N),is_inverse(is_inverse) {}

    complex_t * a;
    complex_t * b;
    complex_t * w;
    const int N;
    const bool is_inverse;

};
struct firstStage: ff_node_t <myTask> {
    firstStage(const size_t streamlength, const size_t npoints):
    streamlength(streamlength), npoints(npoints) {}

    int svc_init() { //here twiddler calc, once for all
        clock_gettime(CLOCK_MONOTONIC, &startt_twiddler);
        w = (complex_t*) malloc(sizeof (complex_t)*npoints/2);
        twiddler(w,npoints, false);
        clock_gettime(CLOCK_MONOTONIC, &endt_twiddler);
        return 0;
    }
    myTask* svc(myTask *) {
        //TODO could recycle "nworkers" preallocated fragment of memory
        //instead of performing multiple malloc/free. Is it better?
        for(size_t i=0; i<streamlength; ++i) {
            a = (complex_t*) malloc(sizeof (complex_t)*npoints);
            fillv(a,npoints);
            b = (complex_t*) malloc(sizeof (complex_t)*npoints);
            ff_send_out(new myTask(a,b,w,npoints,false));
        }
        return EOS;
    }

    complex_t * a;
    complex_t * b;
    complex_t * w;
    const size_t npoints;
    const size_t streamlength;

};
struct myDIFWorker: ff_node_t <myTask> {
    myTask * svc (myTask *task) {
        myTask * t = task;
        fft_dif(t->a,t->b,t->w,t->N,t->is_inverse);
        //here it should 'invert' w to properly antitransform
        fft_dif(t->b,t->a,t->w,t->N,!(t->is_inverse));

        // //check the result
        // sleep(1);
        // prettyprintv(t->a,t->N,"dif worker ");
        // sleep(1);

        return task;
    }
};
struct myDITWorker: ff_node_t <myTask> {

    myTask * svc (myTask *task) {
        myTask * t = task;
        fft_dit(t->a,t->b,t->w,t->N,t->is_inverse);
        //here it should 'invert' w to properly antitransform
        fft_dit(t->b,t->a,t->w,t->N,!(t->is_inverse));

        // //check the result
        // sleep(1);
        // prettyprintv(t->a,t->N,"dit worker ");
        // sleep(1);
        return task;
    }
};
struct lastStage: ff_node_t<myTask> {

    myTask* svc(myTask * task) {
        // myTask * t = task;
        // prettyprintv(t->a,t->N,"laststage"); //check the result
        wref=task->w; //TODO to be reeingineered
            //I have to keep w memory segment allocated so that it can be 'recycled' for
            //the next tasks, but I want to delete everthing else (especially a and b).
            //the framework does not help in keeping w reference in svc_end.
        free(task->a);
        free(task->b);
        delete task;

    }

    void svc_end () {
        free(wref);
    }
    complex_t * wref;
};


int main(int argc, char *argv[]) {

    clock_gettime(CLOCK_MONOTONIC, &startt_main);


    if (argc<4) {
        std::cerr << "Usage: " << argv[0]  << " npoints nworkers streamlength \n"
        << "\t[PARALLEL_MODE [--dif|--dit [--print] ] ] \n"
        << "See the project report for further information" << std::endl;
        return -1;
    }


    const size_t npoints = std::stol(argv[1]);
    if (!is_powerOfTwo(npoints)) {
        std::cerr << "\tBad input, npoints must be greater than 15 and a power of 2" << std::endl;
        return -1;
    }

    const size_t nworkers = std::stol(argv[2]);
    const size_t streamlen = std::stol(argv[3]);

    enum parallel_mode { FFFARM, SEQ, OLOMP, FFPF, OLFFPF, TESTOLOMP, TESTFFPF, TESTOLFFPF,TESTSLOWFUN, TESTSERACC, TESTALL };
    parallel_mode pm = SEQ;
    if (argc >= 5) {
        if (std::string(argv[4]) == "--fffarm") { pm = FFFARM; }
        else if (std::string(argv[4]) == "--seq") { pm = SEQ; }
        else if (std::string(argv[4]) == "--olomp") { pm = OLOMP; }
        else if (std::string(argv[4]) == "--olffpf") { pm = OLFFPF; }
        else if (std::string(argv[4]) == "--ffpf") { pm = FFPF; }
        else if (std::string(argv[4]) == "--testall") { pm = TESTALL; }
        else if (std::string(argv[4]) == "--testolomp") { pm = TESTOLOMP; }
        else if (std::string(argv[4]) == "--testolffpf") { pm = TESTOLFFPF; }
        else if (std::string(argv[4]) == "--testffpf") { pm = TESTFFPF; }
        else if (std::string(argv[4]) == "--testslowfun") { pm = TESTSLOWFUN; }
        else if (std::string(argv[4]) == "--testseracc") { pm = TESTSERACC; }
        else { std::cerr << "\n\targv[4] parse error, Did you mean --seq|--ffpf|--olffpf|--olomp|--fffarm in argv no. 4?" << std::endl; return -1; }
    }

    bool decimation_in_freq = false;
    if (argc >= 6) {
        if (std::string(argv[5]) == "--dif") {
            decimation_in_freq = true;
        } else if (std::string(argv[5]) == "--dit") {
            decimation_in_freq = false;
        } else  std::cerr << "\n\targv[5] parse error, Did you mean --dif|--dit ?"<< std::endl;
    }

    bool print = false;
    if (argc >= 7) print = (std::string(argv[6]) == "--print");


    if (decimation_in_freq) {

        if (pm != SEQ) {
            std::cerr << "diF algorithms different from --seq are not defined yet" << std::endl;
            return -1;
        }

        complex_t * in = (complex_t*) malloc(sizeof (complex_t)*npoints);
        complex_t * out = (complex_t*) malloc(sizeof (complex_t)*npoints);
        fillv(in,npoints);
        if (print) prettyprintv(in,npoints,"\n Input Data:");

        complex_t * w = (complex_t*) malloc(sizeof (complex_t)*(npoints/2));
        clock_gettime(CLOCK_MONOTONIC, &startt_twiddler);
        twiddler(w,npoints, false);
        clock_gettime(CLOCK_MONOTONIC, &endt_twiddler);


        fft_dif(in,out,w,npoints,false);
        if (print) prettyprintv(out,npoints,"\n Transformed Data:");
        twiddler(w,npoints, true);
        fft_dif(out,in,w,npoints,true);
        if (print) prettyprintv(in,npoints,"\n Input Data Back:");

    }
    else {
        switch (pm) {
            case FFFARM: {
                std::cout << "--print version for --fffarm not defined yet, going on without printing" << std::endl;

                firstStage first(streamlen,npoints);
                lastStage last;

                if (!decimation_in_freq) {
                    ff_Farm <myTask> farm ( [nworkers]() {
                        std::vector<std::unique_ptr<ff_node>> Workers;
                        for (int i=0; i<nworkers; ++i) {
                            Workers.push_back(make_unique<myDITWorker>() );
                        }
                        return Workers;
                    } () );
                    ff_Pipe<> pipe (first,farm,last);
                    if (pipe.run_and_wait_end() < 0) error ("running pipe");
                } else {
                    ff_Farm <myTask> farm ( [nworkers]() {
                        std::vector<std::unique_ptr<ff_node>> Workers;
                        for (int i=0; i<nworkers; ++i) {
                            Workers.push_back(make_unique<myDIFWorker>() );
                        }
                        return Workers;
                    } () );
                    ff_Pipe<> pipe (first,farm,last);
                    if (pipe.run_and_wait_end() < 0) error ("running pipe");
                }

            } break;
            case TESTALL: {
                fft_massive_tests(fft_dit_olomp,streamlen,"dit_olomp");
                fft_massive_tests(fft_dit_olffpf,streamlen,"dit_olffpf");
                fft_massive_tests(fft_dit_ffpf,streamlen,"dit_ffpf");
                fft_massive_tests(fft_dit_ffpf_slowfun,streamlen,"slowfun_dit_ffpf");
                fft_massive_tests(fft_dit_ffpf_seracc,streamlen,"seracc_dit_ffpf");
            } break;
            case TESTOLOMP: {
                fft_massive_tests(fft_dit_olomp,streamlen,"dit_olomp");
            } break;
            case TESTOLFFPF: {
                fft_massive_tests(fft_dit_olffpf,streamlen,"dit_olffpf");
            } break;
            case TESTFFPF: {
                fft_massive_tests(fft_dit_ffpf,streamlen,"dit_ffpf");
            } break;
            case TESTSLOWFUN: {
                fft_massive_tests(fft_dit_ffpf_slowfun,streamlen,"slowfun_dit_ffpf");
            } break;
            case TESTSERACC: {
                fft_massive_tests(fft_dit_ffpf_seracc,streamlen,"seracc_dit_ffpf");
            } break;
            default: {

                complex_t * in = (complex_t*) malloc(sizeof (complex_t)*npoints);
                complex_t * out = (complex_t*) malloc(sizeof (complex_t)*npoints);
                fillv(in,npoints);
                if (print) prettyprintv(in,npoints,"\n Input Data:");

                complex_t * w = (complex_t*) malloc(sizeof (complex_t)*(npoints/2));
                clock_gettime(CLOCK_MONOTONIC, &startt_twiddler);
                twiddler(w,npoints, false);
                clock_gettime(CLOCK_MONOTONIC, &endt_twiddler);

                switch (pm) {
                    case SEQ: {

                        //trick. here I get the cleanest execution time, so I can estimate f in Ahmdal law
                        if (streamlen==0) {
                            std::cout << "*** trick ***" << std::endl;
                            fft_dit(in,out,w,npoints,false);
                        } else {
                            for (int i=0;i<streamlen;i++) {
                                fft_dit(in,out,w,npoints,false);
                                if (print) prettyprintv(out,npoints,"\n Transformed Data:");
                                twiddler(w,npoints, true);
                                fft_dit(out,in,w,npoints,true);
                                if (print) prettyprintv(in,npoints,"\n Input Data Back:");
                            }
                        }

                    } break ;
                    case OLOMP: {

                        for (int i=0;i<streamlen;i++) {
                            fft_dit_olomp(0,in,out,w,npoints,false);
                            if (print) prettyprintv(out,npoints,"\n Transformed Data:");
                            twiddler(w,npoints, true);
                            fft_dit_olomp(0,out,in,w,npoints,true);
                            if (print) prettyprintv(in,npoints,"\n Input Data Back:");
                        }

                    } break;
                    case OLFFPF: {

                        for (int i=0;i<streamlen;i++) {
                            fft_dit_olffpf(nworkers,in,out,w,npoints,false);
                            if (print) prettyprintv(out,npoints,"\n Transformed Data:");
                            twiddler(w,npoints, true);
                            fft_dit_olffpf(nworkers,out,in,w,npoints,true);
                            if (print) prettyprintv(in,npoints,"\n Input Data Back:");
                        }

                    } break;
                    case FFPF: {

                        for (int i=0;i<streamlen;i++) {
                            fft_dit_ffpf(nworkers,in,out,w,npoints,false);
                            if (print) prettyprintv(out,npoints,"\n Transformed Data:");
                            twiddler(w,npoints, true);
                            fft_dit_ffpf(nworkers,out,in,w,npoints,true);
                            if (print) prettyprintv(in,npoints,"\n Input Data Back:");
                        }

                    } break;
                    default: {
                        std::cerr << "*** un-matched parallel_mode ***" << std::endl;
                    }

                }

                free(w);
                free (in);
                free (out);

            }

        }

    }



    clock_gettime(CLOCK_MONOTONIC, &endt_main);
    std::cout<< "  twi \t nsec (CLOCK_MONOTONIC) = "<<time2Double(timediff(startt_twiddler,endt_twiddler))<<std::endl;
    std::cout<< "* fft \t nsec (CLOCK_MONOTONIC) = "<<time2Double(timediff(startt_fft,endt_fft)) <<" *"<<std::endl;
    std::cout<< "  Tot \t nsec (CLOCK_MONOTONIC) = "<<time2Double(timediff(startt_main,endt_main))<<std::endl;

    std::cout << "Input argv were:\t ";
    for (int i=1; i<argc; i++) {
        std::cout << std::string(argv[i]) + " ";
    }
    std::cout << std::endl;


    return 0;

}
